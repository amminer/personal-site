* Overall functionality (Dockerfiles, Docker Hub images)

* Screenshots as described in assignment included

* Instructions followed accurately including naming and submission of code